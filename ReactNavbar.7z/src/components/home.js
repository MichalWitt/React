import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Home.css';
import Coin from './Coin';

function Home() {
  
  const [coins, setCoins] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    axios
      .get(
        'https://api.coingecko.com/api/v3/coins/markets?vs_currency=pln&order=market_cap_desc&per_page=50&page=1&sparkline=false'
      )
      .then(res => {
        setCoins(res.data);
        console.log(res.data);
      })
      .catch(error => console.log(error));
  }, []);

  const handleChange = e => {
    setSearch(e.target.value);
  };

  const filteredCoins = coins.filter(coin =>
    coin.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    
    <div className='coin-app'>
      <div className='coin-search'>
        
        <form>
          <input
            className='coin-input'
            type='text'
            onChange={handleChange}
            placeholder='SEARCH CRYPTO'
          />
        </form>
      </div>
      <div className='coin-container'>
        <div className='coin-row'>
          
          <div className='coin pad'>  
              <h1>NAME</h1>
              <p className='coin-symbol bd'>SYMBOL</p>
          </div>
          <div className='coin-data bd'>
            <p className='coin-price bd'>PRICE</p>
            <p className='coin-volume bd'>VOLUMEN 24h</p>
            <p className='coin-percent white bd'>24h</p>
            <p className='coin-marketcap bd'>CAPITALIZATION</p>
          </div>
        </div>
      </div>
      {filteredCoins.map(coin => {
        return (
          <Coin
            key={coin.id}
            name={coin.name}
            price={coin.current_price}
            symbol={coin.symbol}
            marketcap={coin.market_cap}
            volume={coin.total_volume}
            image={coin.image}
            priceChange={coin.price_change_percentage_24h}
          />
          
        );
      })}
      
    </div>
  );
}

export default Home;
