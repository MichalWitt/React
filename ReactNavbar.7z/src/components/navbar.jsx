import "../navbar.css";
import {Link} from 'react-router-dom'
import { useEffect, useState } from 'react';
import jwt_decode from "jwt-decode";

function Navbar() {

  const [ user, setUser ] = useState({});

  function handleCallbackResponse(response) {
    console.log("Encoded JWT ID token: " + response.credential);
    var userObject = jwt_decode(response.credential);
    console.log(userObject);
    setUser(userObject);
    document.getElementById("signInDiv").hidden = true;
  }

  function handleSignOut(event) {
    setUser({});
    document.getElementById("signInDiv").hidden = false;
  }

  useEffect(() => {
    /* global google */
    google.accounts.id.initialize({
      client_id: "905910666451-e0ive5olb97g1dkmjg2qquqssqib5m5q.apps.googleusercontent.com",
      callback: handleCallbackResponse
    });

    google.accounts.id.renderButton(
      document.getElementById("signInDiv"),
      { theme: "outline", size: "large"}
    );
    
    google.accounts.id.prompt();
  }, []);

  const [active, setActive] = useState("nav__menu");
  const [icon, setIcon] = useState("nav__toggler");
  const navToggle = () => {
    if (active === "nav__menu") {
      setActive("nav__menu nav__active");
    } else setActive("nav__menu");

    // Icon Toggler
    if (icon === "nav__toggler") {
      setIcon("nav__toggler toggle");
    } else setIcon("nav__toggler");
  };
  return (
    <nav className="nav">
      <Link to='/' className="nav__brand">
        Cryptosfera
      </Link>
      <ul className={active}>
        <li className="nav__item">
          <Link to='/' className="nav__link">Home</Link>
        </li>

        <li className="nav__item">
          <Link to='/chartapp' className="nav__link">Bitcoin Chart</Link>
        </li>
        
        <li className="nav__item">
          <Link to='./contact' className="nav__link">Contact</Link>
        </li>

        <div id="signInDiv"></div>
        { Object.keys(user).length != 0 &&
        <button onClick={ (e) => handleSignOut(e)}>Sign Out</button>
        }
        { user &&
        <div>
          
          <h3>{user.name}</h3>
        </div>
        }

      </ul>
      <div onClick={navToggle} className={icon}>
        <div className="line1"></div>
        <div className="line2"></div>
        <div className="line3"></div>
      </div>
      
    </nav>
    
  );
}

export default Navbar;
