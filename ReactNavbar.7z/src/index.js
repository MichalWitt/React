import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import "./navbar.css";
import App from './App';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import reportWebVitals from './reportWebVitals';
import Contact from './components/contact';
import Chartapp from './components/chartapp';
import Navbar from "./components/navbar";


ReactDOM.render(
  <Router>
    <div>
        <Navbar/>
        <Routes>
            <Route path='/' element={<App/>}/>
            <Route path='/contact' element={<Contact/>}/>
            <Route path='/chartapp' element={<Chartapp/>}/>
        </Routes>
    </div>
  </Router>,

  document.getElementById('root')
);


reportWebVitals();
